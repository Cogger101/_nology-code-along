package com.example.spring_mysql_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMysqlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
